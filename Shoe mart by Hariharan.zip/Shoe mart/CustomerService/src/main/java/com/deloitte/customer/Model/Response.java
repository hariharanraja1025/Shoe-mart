package com.deloitte.customer.Model;

import java.util.List;

import com.deloitte.customer.Entity.Customer;

public class Response {

	private List<Customer> customerResponse;
	private List<ShoeOrder> ShoeOrderResponse;
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Response(List<Customer> customerResponse, List<ShoeOrder> shoeOrderResponse) {
		super();
		this.customerResponse = customerResponse;
		ShoeOrderResponse = shoeOrderResponse;
	}
	public List<Customer> getCustomerResponse() {
		return customerResponse;
	}
	public void setCustomerResponse(List<Customer> customerResponse) {
		this.customerResponse = customerResponse;
	}
	public List<ShoeOrder> getShoeOrderResponse() {
		return ShoeOrderResponse;
	}
	public void setShoeOrderResponse(List<ShoeOrder> shoeOrderResponse) {
		ShoeOrderResponse = shoeOrderResponse;
	}
	
	
	
	
	
}
