package com.deloitte.customer.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="customers")
public class Customer {
	
	@Id
	  @GeneratedValue(strategy= GenerationType.AUTO)
	private  Integer customerid;
	private String customerName;
	private Integer customerNumber;
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(Integer customerid, String customerName, Integer customerNumber) {
		super();
		this.customerid = customerid;
		this.customerName = customerName;
		this.customerNumber = customerNumber;
	}
	public Integer getCustomerid() {
		return customerid;
	}
	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Integer getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(Integer customerNumber) {
		this.customerNumber = customerNumber;
	}


	
	
}
