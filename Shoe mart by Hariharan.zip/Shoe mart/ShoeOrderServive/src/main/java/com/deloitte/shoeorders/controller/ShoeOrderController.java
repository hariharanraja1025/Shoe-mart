package com.deloitte.shoeorders.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.shoeorders.entity.ShoeOrder;
import com.deloitte.shoeorders.service.ShoeOrderServiceImpl;

@RestController
@RequestMapping("/orders")
public class ShoeOrderController {

	@Autowired
	ShoeOrderServiceImpl orderServiceImpl;
	
	@GetMapping("/getOrders")
	public ResponseEntity<List<ShoeOrder>> getAllOrders(){
		
    List<ShoeOrder> orders=orderServiceImpl.getOrders();
		return new ResponseEntity<List<ShoeOrder>>(orders,HttpStatus.OK);
	}
	
	@GetMapping("/getOrder/{cid}")
	public ResponseEntity<List<ShoeOrder>> getOrderByCId(@PathVariable("cid") Integer cid) {
		
			List<ShoeOrder> order=orderServiceImpl.getOrder(cid);
			return new ResponseEntity<List<ShoeOrder>>(order,HttpStatus.OK);
		}
	}
