package com.deloitte.shoeorders.service;

import java.util.List;

import com.deloitte.shoeorders.entity.ShoeOrder;

public interface ShoeOrderService {

	public List<ShoeOrder> getOrders();
	public List<ShoeOrder> getOrder(Integer id);
	
	
}
