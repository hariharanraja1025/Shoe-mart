package com.deloitte.shoeorders.repo;

import org.springframework.stereotype.Repository;

import com.deloitte.shoeorders.entity.ShoeOrder;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ShoeOrderRepository extends  JpaRepository<ShoeOrder, Integer> {

	public List<ShoeOrder> findByCid(Integer custId);
	
	
	
}
