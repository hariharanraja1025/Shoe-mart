package com.deloitte.shoeorders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoeOrderServiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoeOrderServiveApplication.class, args);
	}

}
