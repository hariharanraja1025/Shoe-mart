package com.deloitte.shoeorders.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.shoeorders.entity.ShoeOrder;
import com.deloitte.shoeorders.repo.ShoeOrderRepository;

@Service
public class ShoeOrderServiceImpl  implements ShoeOrderService{

	@Autowired
	ShoeOrderRepository orderRepository;
	@Override
	public List<ShoeOrder> getOrders() {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
	}

	@Override
	public List<ShoeOrder> getOrder(Integer id) {
		// TODO Auto-generated method stub
		return orderRepository.findByCid(id);
	}

}
